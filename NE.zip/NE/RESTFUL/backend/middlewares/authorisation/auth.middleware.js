const jwt = require('jsonwebtoken')
const config = require('config');
const {USER_STATUS_ENUM} = require("../../utils/enumerations/constants");
const {User} = require('../../models/user.model');

const {API_RESPONSE} = require("../../utils/common");


const decryptToken = (encrypted) =>{
    if(!encrypted) return null;
    try {
        return {token: encrypted};
    }
    catch (e) {
        return (API_RESPONSE(false,  'Invalid Token', null, 400))
    }
}



exports.AUTH_MIDDLEWARE = async (req, res, next) => {

    const header = req.header('Authorization');
    if (!header || !(header.startsWith('Bearer ')))
        return res.send(API_RESPONSE(false,  'No Token Found', null, 400)).status(401);

    const {token} = decryptToken(header.split(' ')[1]);
    if (!token) return res.send(API_RESPONSE(false,  'Invalid Bearer Token', null, 400)).status(401)

    try {
        const decoded = jwt.verify(token, config.get('KEY'));
        const user = await User.findOne({ _id: decoded.id, status: USER_STATUS_ENUM.ACTIVE }).populate('category')
        if (!user) return res.status(404).send(API_RESPONSE(false,  'Invalid User Account', null, 400));

        const userCategory = user.category;

        let AUTH_DATA = {};

        switch (userCategory) {
            case 'CUSTOMER':
                AUTH_DATA = {
                    USER_TYPE: userCategory,
                    USER_ID: user._id
                }
                break;
            case 'SYSTEM_ADMIN':
                AUTH_DATA = {
                    USER_TYPE: userCategory,
                    USER_ID: user._id
                }
                break;
        }

        req.AUTH_DATA = AUTH_DATA;
        next();
    }
    catch (err) {
        return res.send(API_RESPONSE(false,  'Invalid Bearer Token', null, 400)).status(400)
    }
}
