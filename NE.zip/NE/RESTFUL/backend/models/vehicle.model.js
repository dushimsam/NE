const mongoose = require('mongoose');
const timestamps = require('mongoose-timestamp');
const Joi = require("joi");
const {registerSchema} = require('swaggiffy')
const pagination = require("mongoose-paginate-v2");

const vehicleSchema = new mongoose.Schema({
    chassis_number: {
      type: String,
      required: true,
    },
    plate_number: {
      type: String,
      required: true,
      unique: true
    },
    model_name: {
      type: String,
      required: true,
    },
    company: {
      type: String,
      required: true,
    },
    description: {
      type: String,
      required: true,
    },
    year: {
      type: Number,
      required: true,
    },
    price: {
      type: Number,
      required: true,
    },
  });
  
  vehicleSchema.plugin(pagination);
  vehicleSchema.plugin(timestamps);
  
  const Vehicle = mongoose.model("Vehicle", vehicleSchema);
  registerSchema('Vehicle',vehicleSchema,{orm:'mongoose'})
  
  function validateVehicle(data) {
    const schema = {
      chassis_number: Joi.string().required(),
      plate_number: Joi.string().required(),
      model_name: Joi.string().required(),
      company: Joi.string().required(),
      description: Joi.string().required(),
      year: Joi.number().required(),
      price: Joi.number().required(),
    };
  
    return Joi.validate(data, schema);
  }
  
  module.exports.Vehicle = Vehicle;
  module.exports.validateVehicle = validateVehicle;
  