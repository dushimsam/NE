const mongoose = require("mongoose");
const Joi = require("joi");
const timestamps = require("mongoose-timestamp");
const pagination = require('mongoose-paginate-v2');
const {registerSchema} = require('swaggiffy')


const schema = new mongoose.Schema({
    customer: {
       type: mongoose.Schema.Types.ObjectId,
       required: true,
       ref: "Customer"
    },
    vehicle: {
        type: mongoose.Schema.Types.ObjectId,
        required: true,
        ref: "Vehicle"
    }
});

schema.plugin(timestamps);
schema.plugin(pagination);
registerSchema('VehicleOwner',schema,{orm:'mongoose'})
exports.VehicleOwner = mongoose.model("VehicleOwner", schema);

