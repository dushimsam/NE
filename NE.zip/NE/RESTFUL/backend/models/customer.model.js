const mongoose = require("mongoose");
const Joi = require("joi");
const timestamps = require("mongoose-timestamp");
const pagination = require('mongoose-paginate-v2');
const {registerSchema} = require('swaggiffy')


const customerSchema = new mongoose.Schema({
    names: {
       type: String,
         required: true,
    },
    nationalId: {
        type: String,
        required: true,
    },
    phone:{
        type: String,
        required: true,
    },
    address:{
        type: String,
        required: true,
    }
});
customerSchema.plugin(timestamps);
customerSchema.plugin(pagination);
exports.Customer = mongoose.model("Customer", customerSchema);
registerSchema('Customer',customerSchema,{orm:'mongoose'})

