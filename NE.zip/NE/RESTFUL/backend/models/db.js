const mongoose = require("mongoose");
const path = require("path");

const db = 'mongodb://localhost:27017/VEHICLE_MANAGEMENT_SYSTEM';

mongoose.set('toObject', {virtuals: true});

const connectDB = async () => {
    try {
        await mongoose.connect(db, {
            useUnifiedTopology: true,
            useNewUrlParser: true,
            useFindAndModify: false,
        });
    } catch (err) {
        process.exit(1);
    }
};

connectDB().then( () => console.log ("Connected to DB" )) 
.catch( (err) => console.error("Could not connect to MongoDB"))
