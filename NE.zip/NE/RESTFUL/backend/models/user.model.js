const mongoose = require('mongoose');
const joi = require('joi');
const {joiPassword} = require('joi-password');
const { registerSchema } = require('swaggiffy');
const jwt = require('jsonwebtoken');
const timestamps = require('mongoose-timestamp');
const pagination = require('mongoose-paginate-v2')
const {toTimestamp} = require("../utils/common");


const userSchema = new mongoose.Schema({
    names: {
        type: String,
        unique: true,
        required: true
    },
    email: {
        type: String
    },
    phone: {
        type: String
    },
    nationalId: {
        type: String
    },
    password: {
        type: String,
        required: true
    },
    category:{
        type: String,
        default:"SYSTEM_ADMIN",
        required: true
    }

});

userSchema.plugin(timestamps);
userSchema.plugin(pagination);
registerSchema('User',userSchema,{orm:'mongoose'})
const User = mongoose.model("User", userSchema);



userSchema.methods.generateAuthToken = function () {
    return jwt.sign(
        {
            id: this._id,
            names: this.names,
            email: this.email,
            phone: this.phone,
            exp: toTimestamp(),
        }
    )
};


exports.validateUser = (user) => {
    const schema = {
         names: Joi.string().required(),
    }
    return Joi.validate(user, schema)
}
exports.validateLogin = (data) => {
    const schema = {
        email: Joi.string().required(),
        password: Joi.string().required(),
    }
    return Joi.validate(data, schema)
}

exports.User = User;


