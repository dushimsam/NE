const express = require("express");
const dotenv = require("dotenv");
const mongoose = require("mongoose");

const app = express();
dotenv.config();
const cors = require("cors");
const bodyParser = require("body-parser");
const {Swaggiffy} = require("swaggiffy");
new Swaggiffy().setupExpress(app).swaggiffy();

app.use(cors());
app.use(express.json())

const env = process.env.NODE_ENV || "development";

const DB_URL =  env === "container" ? process.env.DB_URL_CONTAINER : process.env.DB_URL_DEV


const userController = require("./controllers/user.controller");
const vehicleController = require("./controllers/vehicle.controller");
const authController = require("./controllers/auth.controller");
const ownerController = require('./controllers/vehicle.owner.controller');
const customerController = require('./controllers/customer.controller');

// Connect to MongoDB
// mongoose.connect(DB_URL)
// .then( () => console.log ("Connected to DB" )) 
// .catch( (err) => console.error("Could not connect to MongoDB"))
// require("./models/db");

const connectToMongo = async () => {
    try {
      await mongoose.connect("mongodb+srv://dushsam:Y6DyLqGs8U6KQg9@cluster0.vafjg.mongodb.net/vehicle_management", { useNewUrlParser: true });
      console.log('connected to MongoDB');
    } catch(error) {
      console.log('error connection to MongoDB:', error.message);
    }
  };
  connectToMongo()

// User Routes
app.use('/api/users', userController);

// Auth Routes
app.use('/api/auth', authController);


// customer Routes
app.use('/api/customers', customerController);


// Vehicle owners Routes
app.use('/api/vehicle-owners', ownerController);

// Vehicle
app.use('/api/vehicles', vehicleController);

// Welcome Route
app.get('/', (req,res) => {
    res.send('VEHICHLE MANAGEMENT SYSTEM ࡙࡙࡙࡙࡙');
})

app.listen(5008, () => {
    console.log('Server Listening on Port 5008');
})