/**
 * Minimum 8 characters<br>
 * AtLeast 1 UPPERCASE letter<br>
 * AtLeast 1 LOWERCASE letter<br>
 * AtLeast 1 NUMBER<br>
 * AtLeast 1 SPECIAL CHARACTER<br>
 * @type {RegExp}
 */
exports.PASSWORD = /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$/;


/**
 * Value Added Tax Percentage
 * @type {number}
 */
exports.VAT_PERCENTAGE = 18;

/**
 * Digit pattern
 * @type {RegExp}
 */
exports.DIGIT_PATTERN = /^(0|[0-9][0-9]*)$/;


/**
 * One Day TimeStamp
 * @type {number}
 */
exports.ONE_DAY = 24 * 60 * 60 * 1000;


/**
 * Enum: User Category
 * @type {{EMPLOYEE: string, CUSTOMER: string, SYSTEM_ADMIN: string}}
 */
exports.USER_CATEGORY_ENUM = {
    SYSTEM_ADMIN: 'SYSTEM_ADMIN',
    CUSTOMER: 'CUSTOMER',
}
