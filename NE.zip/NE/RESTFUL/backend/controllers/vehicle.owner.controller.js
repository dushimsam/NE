const express = require("express");
const router = express.Router();
const bcrypt = require('bcryptjs');
const {API_RESPONSE, hashPassword} = require("../utils/common");
const { VehicleOwner} = require("../models/vehicle.owner.model");
const {registerDefinition} = require("swaggiffy")


router.get('/', async (req, res) => {
    try {
        const instances = await VehicleOwner.find().sort( { updatedAt: -1 }).populate(populator);
        return res.status(200).send(instances);
    }
    catch (err) {
        return res.status(500).send(API_RESPONSE(false, 'Internal Server Error', err.toString(), 500));
    }
})


router.get('/:id', async (req, res) => {
    try {
        const id = req.params.id;
        if (!validObjectId(id)) {
            return res.status(400).send(API_RESPONSE(false, 'Bad Request', 'Invalid Object Id', 400));
        }
        const instance = await VehicleOwner.findById(id).populate(populator);
        if (!instance) {
            return res.status(404).send(API_RESPONSE(false, 'Not Found', 'Instance not found', 404));
        }
        return res.status(200).send(instance);
    }
    catch (err) {
        return res.status(500).send(API_RESPONSE(false, 'Internal Server Error', err.toString(), 500));
    }
})


router.post('/', async (req, res) => {
    try {
        // const {error} = validateVehicleOwner(req.body);
        // if (error) {    
        //     return res.status(400).send(API_RESPONSE(false, 'Bad Request', error.details[0].message, 400));
        // }
        const instance = new VehicleOwner(req.body);
        const savedInstnace = await instance.save();
        return res.status(201).send(savedInstnace);
    }
    catch (err) {
        return res.status(500).send(API_RESPONSE(false, 'Internal Server Error', err.toString(), 500));
    }
})


registerDefinition(router,{basePath:'/api/vehicle-owners',tags:'VehicleOwner' ,mappedSchema: 'VehicleOwner'});

module.exports = router;