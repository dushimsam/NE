const express = require("express");
const {API_RESPONSE} = require("../utils/common");
const {
    User,
    validateUser,
} = require("../models/user.model");
const {validObjectId, dependencyChecker, hashPassword} = require('../utils/common');
const bcrypt = require('bcryptjs')
const router = express.Router();
const {registerDefinition} = require("swaggiffy");
const { AUTH_MIDDLEWARE } = require("../middlewares/authorisation/auth.middleware");
const { isUserCategory } = require("../middlewares/authorisation/isUserCategory.middleware");
const { USER_CATEGORY_ENUM } = require("../utils/enumerations/constants");


router.get("/", async (req, res) => {
    try {
        const users = await User.find();
        return res.status(200).send(users);
    } catch (err) {
        return res.status(500).send(API_RESPONSE(false, 'Internal Server Error', err.toString(), 500));
    }

});

router.post("/", async (req, res) => {
    try {
        // const {error} = validateUser(req.body);
        // if (error) return res.status(400).send(error.details[0].message);

        const existingEmail = await User.findOne({email: req.body.email});
        if (existingEmail) return res.status(400).send(API_RESPONSE(false, 'User email exists', null, 404));

        req.body.password = await hashPassword(req.body.password);

        const newUser = new User(req.body);
        const saved = await newUser.save();

        if (!saved) return res.status(500).send(API_RESPONSE(false, "User not saved", null, 500));

        return res.status(201).send(saved);
    } catch (err) {
        return res.status(500).send(API_RESPONSE(false, 'An error occurred', err.toString(), 500));
    }
});

registerDefinition(router,{basePath:'/api/users',tags:'User' ,mappedSchema: 'User'});


module.exports = router;
