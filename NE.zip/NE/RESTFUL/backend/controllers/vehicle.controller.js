const express = require("express");
const {AUTH_MIDDLEWARE} = require("../middlewares/authorisation/auth.middleware");
const {isUserCategory} = require("../middlewares/authorisation/isUserCategory.middleware");
const {USER_CATEGORY_ENUM} = require("../utils/enumerations/constants");
const { Vehicle, validateVehicle } = require('../models/vehicle.model.js');
const router = express.Router();
const {API_RESPONSE} = require("../utils/common");
const { validObjectId } = require('../utils/common');
const {registerDefinition} = require("swaggiffy")

router.get('/', [AUTH_MIDDLEWARE, isUserCategory([USER_CATEGORY_ENUM.SYSTEM_ADMIN])], async (req, res) => {
    try {
        const instances = await Vehicle.find().sort( { updatedAt: -1 }).populate(populator);
        return res.status(200).send(instances);
    }
    catch (err) {
        return res.status(500).send(API_RESPONSE(false, 'Internal Server Error', err.toString(), 500));
    }
})

router.get('/:id', [AUTH_MIDDLEWARE, isUserCategory([USER_CATEGORY_ENUM.SYSTEM_ADMIN])], async (req, res) => {
    try {
        const id = req.params.id;
        if (!validObjectId(id)) {
            return res.status(400).send(API_RESPONSE(false, 'Bad Request', 'Invalid Object Id', 400));
        }
        const instance = await Vehicle.findById(id).populate(populator);
        if (!instance) {
            return res.status(404).send(API_RESPONSE(false, 'Not Found', 'Instance not found', 404));
        }
        return res.status(200).send(instance);
    }
    catch (err) {
        return res.status(500).send(API_RESPONSE(false, 'Internal Server Error', err.toString(), 500));
    }
})

router.post('/', [AUTH_MIDDLEWARE, isUserCategory([USER_CATEGORY_ENUM.SYSTEM_ADMIN])], async (req, res) => {
    try {
        const {error} = validateVehicle(req.body);
        if (error) {    
            return res.status(400).send(API_RESPONSE(false, 'Bad Request', error.details[0].message, 400));
        }
        const instance = new Vehicle(req.body);
        const savedInstnace = await instance.save();
        return res.status(201).send(savedInstnace);
    }
    catch (err) {
        return res.status(500).send(API_RESPONSE(false, 'Internal Server Error', err.toString(), 500));
    }
})

registerDefinition(router,{basePath:'/api/vehicles',tags:'Vehicle' ,mappedSchema: 'Vehicle'});

module.exports = router;