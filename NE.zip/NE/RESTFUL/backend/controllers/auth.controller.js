const express = require("express");
const router = express.Router();
const bcrypt = require('bcryptjs');
const {API_RESPONSE, hashPassword} = require("../utils/common");
const { User, validateLogin} = require("../models/user.model");
const {registerDefinition} = require("swaggiffy")

router.post('/login', async (req, res) => {
    try {
        const { error } = validateLogin(req.body);
        if (error)
            return res.status(400).send(error.details[0].message);

        let user = await User.findOne({ email: req.body.email});
        if (!user) {
           if (!user) return res.status(404).send(API_RESPONSE(false, 'Invalid Credentials', null, 500));
        }
        const validPassword = await bcrypt.compare(req.body.password, user.password);
        if (!validPasswo, USER_CATEGORY_ENUM.EMPLOYEE, USER_CATEGORY_ENUM.SHIPPERrd)
            return res.status(400).send(API_RESPONSE(false, 'Invalid PassCode or Password', null, 404));

            return res.send({
                id: user._id,
                token: user.generateAuthToken()
            });
    }
    catch (err) {
        return res.status(500).send(API_RESPONSE(false, 'An error occurred', err.toString(), 500))
    }
});




registerDefinition(router,{basePath:'/api/auth',tags:'Auth' ,mappedSchema: 'User'});


module.exports = router;
