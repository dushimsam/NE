import React, {useState, useEffect} from 'react';
import './App.css'
import Login from './views/auth/login'
import {
  Routes,
  BrowserRouter as Router,
  Route,
  Navigate,
} from 'react-router-dom'
import SignUp from './views/auth/signup'
import AddCustomer from './views/dashboard/add-customer';
import AddVehicle from './views/dashboard/add-vehicle';
import ViewList from './views/dashboard/view-list';

const PrivateRoute =  ({ children }) => {
  const token = localStorage.getItem('token');
  if(!token) return <Navigate to="/" />
  return children;
}

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Login />} />
        <Route path="/signup" element={<SignUp />} />
        <Route path="/add-customer" element={<AddCustomer />} />
        <Route path="/add-vehicle" element={<AddVehicle />} />
        <Route path="/view-list" element={<ViewList />} />
        {/* <Route
          path="/add-customer"
          element={
            <PrivateRoute>
              <AddCustomer />
            </PrivateRoute>
          }
        /> */}
      </Routes>
    </Router>
  )
}

export default App
