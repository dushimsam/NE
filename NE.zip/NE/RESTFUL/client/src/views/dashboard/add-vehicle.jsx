import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useFormik } from "formik";
import * as Yup from "yup";
import toast, { Toaster } from "react-hot-toast";
import "../../styles/common.css";
import customerImg from '../../assets/images/customer.png';
import CustomerService from "../../services/customer/customer.service";

const AddForm = () => {
  const [requestError, setRequestError] = useState(false);
  const navigate = useNavigate();

  const errorInputStyle = {
    border: "1px solid red",
  };

  const initialValues = {
    chassis_number:"",
    plate_number: "",
    model_name:"",
    company:"",
    description: "",
    year: "",
    price: "",
  };
  const validationSchema = Yup.object().shape({
    chassis_number: Yup.string().required("chassis number is required"),
    plate_number: Yup.string().email("Plate number is invalid").required("Plate number id is required"),
    model_name:  Yup.string().required("Model name is required"),
    company:  Yup.string().required("company is required"),
    description:  Yup.string().required("description is required"),
    year:  Yup.string().required("Year is required"),
    price:  Yup.number().required("Price is required"),
  });

  const formik = useFormik({
    initialValues,
    validationSchema,
  });
  const { values, errors, touched, isValid, getFieldProps } = formik;

  const handleSubmit = async (e) => {
    e.preventDefault();
    setRequestError(false);
    const response = await CustomerService.create(values);
    if (!response?.success)
      return setRequestError(response?.message || "Something went wrong");
    toast.success("Registered successful");
  };
  return (
    <div className="container">
      <Toaster />
      <div className="form-container">
        <form>
          {requestError && <div className="error-message">{requestError}</div>}
          <input
            placeholder="Chassis number"
            type={"chassis_number"}
            style={errors.chassis_number && touched.chassis_number ? errorInputStyle : {}}
            name="chassis_number"
            {...getFieldProps("name")}
          />
          {touched.chassis_number && errors.chassis_number && <label>{errors.name}</label>}

          <input
            placeholder="Plate number"
            type={"text"}
            style={errors.plate_number && touched.plate_number ? errorInputStyle : {}}
            name="plate_number"
            {...getFieldProps("plate_number")}
          />
          {touched.nationalId && errors.plate_number && <label>{errors.plate_number}</label>}

          <input
            placeholder="Model name"
            type={"text"}
            style={errors.model_name && touched.model_name ? errorInputStyle : {}}
            name="model_name"
            {...getFieldProps("model_name")}
          />
          {touched.model_name && errors.model_name && <label>{errors.model_name}</label>}

          <input
            placeholder="Company Name"
            type={"text"}
            style={errors.company && touched.company ? errorInputStyle : {}}
            name="company"
            {...getFieldProps("company")}
          />
          {touched.company && errors.company && <label>{errors.company}</label>}

          <input
            placeholder="Vehicle Release Year"
            type={"text"}
            style={errors.year && touched.year ? errorInputStyle : {}}
            name="year"
            {...getFieldProps("year")}
          />
          {touched.year && errors.year && <label>{errors.year}</label>}

          <input
            placeholder="Vehicle Release Year"
            type={"text"}
            style={errors.price && touched.price ? errorInputStyle : {}}
            name="price"
            {...getFieldProps("price")}
          />
          {touched.price && errors.price && <label>{errors.price}</label>}

          <button
            type="submit"
            className="btn btn-primary"
            disabled={!isValid || Object.values(touched).every((e) => e === "")}
            onClick={handleSubmit}
          >
            SUBMIT 
          </button>
        </form>
      </div>
    </div>
  );
};

const AddVehicle = () => {
  return (
    <div className="container-fluid" style={{ backgroundColor: "#001124" }}>
      <div className="row ">
        <div className="col-md-4 mt-5">
            <h1 className="text-light">Add New Vehicle</h1>
            <div className="">
            <img src={customerImg} alt="Logo" width={300} />
            </div>
        </div>
        <div className="col-md-8">
          <AddForm />
        </div>
      </div>
    </div>
  );
};

export default AddVehicle;
