import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useFormik } from "formik";
import * as Yup from "yup";
import toast, { Toaster } from "react-hot-toast";
import "../../styles/common.css";
import customerImg from '../../assets/images/customer.png';
import CustomerService from "../../services/customer/customer.service";

const AddForm = () => {
  const [requestError, setRequestError] = useState(false);
  const navigate = useNavigate();

  const errorInputStyle = {
    border: "1px solid red",
  };

  const initialValues = {
    name: "",
    nationalId: "",
    phone: "",
    address:""
  };
  const validationSchema = Yup.object().shape({
    name: Yup.string().required("Name is required"),
    nationalId: Yup.string().email("National id is invalid").required("National id is required"),
    phone:  Yup.string().required("Name is required"),
    address:  Yup.string().required("Address is required"),
  });

  const formik = useFormik({
    initialValues,
    validationSchema,
  });
  const { values, errors, touched, isValid, getFieldProps } = formik;

  const handleSubmit = async (e) => {
    e.preventDefault();
    setRequestError(false);
    const response = await CustomerService.create(values);
    if (!response?.success)
      return setRequestError(response?.message || "Something went wrong");
    toast.success("Registered successful");
  };
  return (
    <div className="container">
      <Toaster />
      <div className="form-container">
        <form>
          {requestError && <div className="error-message">{requestError}</div>}
          <input
            placeholder="Full Name"
            type={"name"}
            style={errors.name && touched.name ? errorInputStyle : {}}
            name="names"
            {...getFieldProps("name")}
          />
          {touched.name && errors.name && <label>{errors.name}</label>}

          <input
            placeholder="National Id"
            type={"text"}
            style={errors.nationalId && touched.nationalId ? errorInputStyle : {}}
            name="nationalId"
            {...getFieldProps("nationalId")}
          />
          {touched.nationalId && errors.nationalId && <label>{errors.nationalId}</label>}

          <input
            placeholder="Phone Number"
            type={"text"}
            style={errors.phone && touched.phone ? errorInputStyle : {}}
            name="phone"
            {...getFieldProps("phone")}
          />
          {touched.phone && errors.phone && <label>{errors.phone}</label>}

          <input
            placeholder="Address"
            type={"text"}
            style={errors.phone && touched.phone ? errorInputStyle : {}}
            name="address"
            {...getFieldProps("address")}
          />
          {touched.address && errors.address && <label>{errors.address}</label>}


          <button
            type="submit"
            className="btn btn-primary"
            disabled={!isValid || Object.values(touched).every((e) => e === "")}
            onClick={handleSubmit}
          >
            SUBMIT 
          </button>
        </form>
      </div>
    </div>
  );
};

const AddCustomer = () => {
  return (
    <div className="container-fluid" style={{ backgroundColor: "#001124" }}>
      <div className="row ">
        <div className="col-md-4 col-8 mt-5">
            <h1 className="text-light">Add New Customer</h1>
            <div className="">
            <img src={customerImg} alt="Logo" width={300} />
            </div>
        </div>
        <div className="col-md-8 col-8 ">
          <AddForm />
        </div>
      </div>
    </div>
  );
};

export default AddCustomer;
