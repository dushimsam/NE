

const ViewList  = () =>{
  return(
    <div className="container">
<table class="table table-dark">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Car Name</th>
      <th scope="col">Customer</th>
      <th scope="col">Email</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">1</th>
      <td>Hyundai</td>
      <td>Samuel</td>
      <td>dushsam@gmail.com</td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Santafe</td>
      <td>Thornton</td>
      <td>@fat</td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td>Toyota</td>
      <td>the Bird</td>
      <td>@twitter</td>
    </tr>
  </tbody>
</table>
    </div>
  )
}


export default ViewList;