import {useState} from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useFormik } from 'formik'
import * as Yup from 'yup'
import toast, { Toaster } from 'react-hot-toast'
import '../../../styles/common.css'
import UserService from "../../../services/user/user.service";

const SignUp = () => {
  const [requestError, setRequestError] = useState(false);
  const navigate = useNavigate();

  const errorInputStyle = {
    border: '1px solid red',
  }

  const initialValues = {
    name: '',
    email: '',
    password: '',
    nationalId:'',
    phone:''
  }
  const validationSchema = Yup.object().shape({
    name: Yup.string().required('Name is required'),
    email: Yup.string().email('Email is invalid').required('Email is required'),
    nationalId: Yup.string().required('National ID is required'),
    phone: Yup.string().required('Phone is required'),
    password: Yup.string().required('Password is required')
  })

  const formik = useFormik({
    initialValues,
    validationSchema
  });
  const { values, errors, touched, isValid, getFieldProps } = formik;

  const handleSubmit = async (e) => {  
    e.preventDefault();
    setRequestError(false);
    const response = await UserService.create(values);
    if(!response?.success) return setRequestError(response?.message || 'Something went wrong');
    toast.success("Registered successful");
    localStorage.setItem('token', response?.data?.token);
    navigate('/');
}  

  return (
    <div className="container">
      <Toaster />
      <div style={{marginTop:"10em"}} className='form-container border border-dark rounded  p-5' >
        <form>
        {requestError && <div className="error-message">{requestError}</div>}
          <h2>Sign up </h2>
          <input placeholder="Full Name" 
            
           type={'name'}
           style={errors.name && touched.name ? errorInputStyle : {}}
           name='name' 
           {...getFieldProps('name')}
           />
          {touched.name && errors.name && <label>{errors.name}</label>}

          <input placeholder="Email" 
           type={'email'}

           style={errors.email && touched.email ? errorInputStyle : {}}
           name='email' 
           {...getFieldProps('email')}
           />
          {touched.email && errors.email && <label>{errors.email}</label>}


          <input placeholder="National ID" 
           type={'text'}

           style={errors.email && touched.email ? errorInputStyle : {}}
           name='nationalId' 
           {...getFieldProps('nationalId')}
           />
          {touched.nationalId && errors.nationalId && <label>{errors.nationalId}</label>}


          <input placeholder="Phone" 
           type={'text'}

           style={errors.email && touched.email ? errorInputStyle : {}}
           name='phone' 
           {...getFieldProps('phone')}
           />
          {touched.nationalId && errors.nationalId && <label>{errors.nationalId}</label>}


          <input placeholder="Create Password" 
           type={'password'}
           style={errors.password && touched.password ? errorInputStyle : {}}
           name='password' 
           {...getFieldProps('password')}
           />
          {touched.password && errors.password && <label>{errors.password}</label>}

          <button
            type="submit"
            className="btn btn-primary"
            disabled={!isValid || Object.values(touched).every(e => e === '')}
            onClick={handleSubmit}
          >SIGN UP</button>

          <Link to='/'>
              <p style={{marginTop: '2em'}}>Have account ? <span>Login</span></p>
          </Link>

        </form>
      </div>
    </div>
  )
}


const inputStyles ={
    height:20
}
export default SignUp
