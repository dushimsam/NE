export const votes = [
    {
        id: 1,
        name: 'Kenny The Ninja',
        votes: 10,
        avatar: 'https://static.frontendmasters.com/assets/teachers/dodds/thumb@2x.jpg'
    },
    {
        id: 2,
        name: 'Eric Malaba',
        votes: 7,
        avatar: 'https://media.itkonekt.com/2018/12/Minko_Genchev_400x400-2-300x300.png'
    },
    {
        id: 3,
        name: 'Diana Fossey',
        votes: 7,
        avatar: 'https://static.frontendmasters.com/assets/teachers/dodds/thumb@2x.jpg'
    },
    {
        id: 4,
        name: 'Elon Musk',
        votes: 7,
        avatar: 'https://static.frontendmasters.com/assets/teachers/dodds/thumb@2x.jpg'
    },
    {
        id: 5,
        name: 'Sundar Picar',
        votes: 7,
        avatar: 'https://static.frontendmasters.com/assets/teachers/dodds/thumb@2x.jpg'
    },
    {
        id: 6,
        name: 'Jack Ma',
        votes: 8,
        avatar: 'https://static.frontendmasters.com/assets/teachers/dodds/thumb@2x.jpg'
    }
 ]