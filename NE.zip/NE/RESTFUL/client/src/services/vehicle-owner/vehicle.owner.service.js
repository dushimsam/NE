import http from "../http-common";


class VehicleOwnerService {

    getAll() {
        return http.get("/vehicle-owners");
    }

    getAllPaginated(page = 1) {
        return http.get("/vehicle-owners/paginated?limit=5&page=" + page);
    }


    create(data) {
        return http.post("/vehicle-owners", data)
    }


}

export default new VehicleOwnerService();