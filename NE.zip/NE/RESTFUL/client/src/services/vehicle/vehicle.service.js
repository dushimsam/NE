import http from "../http-common";


class VehicleService {

    getAll() {
        return http.get("/vehicles");
    }

    getAllPaginated(page = 1) {
        return http.get("/vehicles/paginated?limit=5&page=" + page);
    }


    create(data) {
        return http.post("/vehicles", data)
    }


}

export default new VehicleService();
