import axios from "axios";
import {
    Routes,
    BrowserRouter as Router,
    Route,
    Navigate,
  } from 'react-router-dom'
export const domain = 'http://localhost:5008';
import AuthService from './auth/auth.service'


const http = axios.create({
    baseURL: `${domain}/api`,
    headers: { 'Content-Type': 'application/json' },
});

http.interceptors.request.use(
    function (config) {
        const token = AuthService.getDecToken();
        if (token) config.headers.Authorization = `Bearer ${token}`;
        return config;
    },
    function (error) {
        return Promise.reject(error);
    }
);

http.interceptors.response.use(
    function (response){
        return Promise.resolve(response)
    },
    function (error) {
        let res = error.response
        if (res?.data && res.data.message === "INVALID BEARER TOKEN")
             alert("INvalid token")
        
        return Promise.reject(error);
    }
)

export default http;