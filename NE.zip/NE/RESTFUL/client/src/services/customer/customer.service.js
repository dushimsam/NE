import http from "../http-common";


class CustomerService {

    getAll() {
        return http.get("/customers");
    }

    getAllPaginated(page = 1) {
        return http.get("/customers/paginated?limit=5&page=" + page);
    }


    create(data) {
        return http.post("/customers", data)
    }


}

export default new CustomerService();