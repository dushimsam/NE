import http from "../http-common";


class UserService {

    getAll() {
        return http.get("/users");
    }

    getAllPaginated(page = 1) {
        return http.get("/users/paginated?limit=5&page=" + page);
    }


    create(data) {
        return http.post("/users", data)
    }


}

export default new UserService();
