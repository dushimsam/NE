# votting-app-client-service
The frontend service for votting app challenge
