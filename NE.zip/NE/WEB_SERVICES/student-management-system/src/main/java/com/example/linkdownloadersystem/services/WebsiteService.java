package com.example.linkdownloadersystem.services;

import com.example.linkdownloadersystem.dto.StudentDtoGet;
import com.example.linkdownloadersystem.dto.StudentDtoPost;
import com.example.linkdownloadersystem.models.Address;
import com.example.linkdownloadersystem.models.Student;
import com.example.linkdownloadersystem.models.Website;
import com.example.linkdownloadersystem.repositories.StudentRepository;
import com.example.linkdownloadersystem.repositories.WebsiteRepository;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class WebsiteService {
    @Autowired
    private WebsiteRepository websiteRepository;

    public Website add(String linkUrl){


    }
}
