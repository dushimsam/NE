package com.example.linkdownloadersystem.models;

import com.sun.istack.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name="websites")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Website {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name="website_name")
    private String websiteName;

    @NotNull
    @Column(nullable = false)
    private LocalDate downloadStartDateTime;


    @NotNull
    @Column(nullable = false)
    private LocalDate downloadEndDateTime;

    @NotNull
    @Column(nullable = false)
    private int totalElapsedTime = 0;

    @NotNull
    @Column(nullable = false)
    private long totalDownloadKilobytes = 0;

    @OneToMany(mappedBy = "website",cascade=CascadeType.ALL,fetch = FetchType.EAGER)
    private List<Link> links = new ArrayList<>();
}
