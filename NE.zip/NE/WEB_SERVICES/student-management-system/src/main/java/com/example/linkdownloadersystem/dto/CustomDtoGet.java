package com.example.linkdownloadersystem.dto;

import lombok.Data;

@Data
public class CustomDtoGet {
    Object data;

}
