package com.example.linkdownloadersystem.models;


import com.sun.istack.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Entity
@Table(name="links")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Link {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name="link_name")
    private String linkName;

    @NotNull
    @Column(nullable = false)
    private int totalElapsedTime = 0;

    @NotNull
    @Column(nullable = false)
    private long totalDownloadKilobytes = 0;

    @ManyToOne
    @JoinTable(name = "website_links",joinColumns={@JoinColumn(name = "website_id")},inverseJoinColumns={@JoinColumn(name = "link_id")})
    private Website website;
}
