#include <bits/stdc++.h>
using namespace std;
#define MAX_INPUT_LEN 60

typedef string s;
typedef vector<string> vs;
typedef vector<int> vi;
typedef fstream F;

const string locationDataFName = "locations.txt";
const string diseaseDataFName = "diseases.txt";
const string casesDataFName = "cases.txt";

F LocationFile;
F DiseaseFile;
F CaseFile;

const map<string, string> error_mess = {
    {"add", "unexpected add command"},
    {"delete", "unexpected delete command"},
    {"list", "unexpected list command"},
    {"where", "unexpected where command"},
    {"cases", "unexpected add command"},
    {"help", "unexpected help command"},
    {"Exit", "unexpected exit command"}};

class Location
{
    int id = 0;
    string locationName;

public:
    Location() {}
    Location(int id, string locationName)
    {
        this->id = id;
        this->locationName = locationName;
    }

    void setId(int id)
    {
        this->id = id;
    }
    int getId()
    {
        return id;
    }

    void setLocationName(string locationName)
    {
        this->locationName = locationName;
    }
    string getLocationName()
    {
        return locationName;
    }

    string toString()
    {
        return to_string(id) + " " + locationName;
    }
};

class Disease
{
    int id = 0;
    string diseaseName;

public:
    Disease() {}
    Disease(int id, string diseaseName)
    {
        this->id = id;
        this->diseaseName = diseaseName;
    }

    void setId(int id)
    {
        this->id = id;
    }

    
    int getId()
    {
       return  this->id;
    }
    void setDiseaseName(string diseaseName)
    {
        this->diseaseName = diseaseName;
    }
    string getDiseaseName()
    {
        return this->diseaseName;
    }

    string toString()
    {
        return to_string(id) + " " + diseaseName;
    }
};

class Case
{
    int id;
    Location location;
    Disease disease;
    int count = 0;

public:
    Case() {}
    Case(int id, Location location, Disease disease, int count)
    {
        this->id = id;
        this->location = location;
        this->disease = disease;
        this->count = count;
    }

    void setId(int id)
    {
        this->id = id;
    }
    int getId()
    {
        return this->id;
    }

    void setDisease(Disease disease)
    {
        this->disease = disease;
    }
    Disease getDisease()
    {
        return this->disease;
    }

    void setLocation(Location location)
    {
        this->location = location;
    }
    Location getLocation()
    {
        return this->location;
    }

    void setCount(int count)
    {
        this->count = count;
    }

    int getCount()
    {
        return this->count;
    }

    string toString()
    {
        return to_string(id) + " " + to_string(location.getId()) + " " + to_string(disease.getId()) + " " + to_string(count);
    }
};

/***  OPENNING DIFFERENT FILES ***/

bool openLocationF(string mode)
{
    if (mode == "a")
    {
        LocationFile.open(locationDataFName, ios::app);
    }
    else if (mode == "r")
    {
        LocationFile.open(locationDataFName, ios::in);
    }

    return LocationFile.is_open();
}

bool openDiseaseF(string mode)
{
    if (mode == "a")
    {
        DiseaseFile.open(diseaseDataFName, ios::app);
    }
    else if (mode == "r")
    {
        DiseaseFile.open(diseaseDataFName, ios::in);
    }

    return DiseaseFile.is_open();
}

bool openCaseF(string mode)
{
    if (mode == "a")
    {
        CaseFile.open(casesDataFName, ios::app);
    }
    else if (mode == "r")
    {
        CaseFile.open(casesDataFName, ios::in);
    }

    return CaseFile.is_open();
}

/*** HELPER FUNCTIONS ***/

vs extractWrds(s ln)
{
    istringstream ss(ln);
    vs words;
    s word;

    while (ss >> word)
    {
        words.push_back(word);
    }

    return words;
}

string convertToUpper(string input){
  transform(input.begin(), input.end(), input.begin(), ::toupper);
   return input;
}

string convertToLower(string input){
   transform(input.begin(), input.end(), input.begin(), ::tolower);
   return input;
}
/*** INSERTING DATA ***/

bool insertLocation(Location location)
{
    if (openLocationF("a"))
    {
        location.setLocationName(convertToLower(location.getLocationName()));
        LocationFile << location.toString() << "\n";
        LocationFile.close();
        return true;
    }

    return false;
}

bool insertDisease(Disease disease)
{
    if (openDiseaseF("a"))
    {
        disease.setDiseaseName(convertToLower(disease.getDiseaseName()));
        DiseaseFile << disease.toString() << "\n";
        DiseaseFile.close();
        return true;
    }
    return false;
}

bool insertCase(Case dCase)
{
    if (openCaseF("a"))
    {
        CaseFile << dCase.toString() << "\n";
        CaseFile.close();
        return true;
    }
    return false;
}

int caseExists(int locationId, int diseaseId)
{

    if (openCaseF("r"))
    {
        s ln;
        while (getline(CaseFile, ln))
        {
            if (ln != "")
            {
                vs words = extractWrds(ln);
                if (words[1] == to_string(locationId) && words[2] == to_string(diseaseId))
                {
                    return stoi(words[0]);
                }
            }
        }
        CaseFile.close();
    }

    return 0;
}

/*** RETRIEVING  DATA ***/

vs findAllLocations()
{
    vs locations;

    if (openLocationF("r"))
    {
        s ln;
        while (getline(LocationFile, ln))
        {
            if (ln != "")
            {
                vs words = extractWrds(ln);
                locations.push_back(words[1]);
            }
        }
        LocationFile.close();
    }

     sort(locations.begin(), locations.end());
     return locations;
}

vs findAllDiseases()
{
    vs diseases;

    if (openDiseaseF("r"))
    {
        s ln;
        while (getline(DiseaseFile, ln))
        {
            if (ln != "")
            {
                vs words = extractWrds(ln);
                diseases.push_back(words[1]);
            }
        }
        DiseaseFile.close();
    }

     sort(diseases.begin(), diseases.end());
     return diseases;
}

vi findLocationsByDisease(int diseaseId)
{
    vi locations;
    if (openCaseF("r"))
    {
        s ln;
        while (getline(CaseFile, ln))
        {
            if (ln != "")
            {
                vs words = extractWrds(ln);
                locations.push_back(stoi(words[1]));
            }
        }
        CaseFile.close();
    }
    return locations;
}

Disease getDiseaseByName(string name)
{
    if (openDiseaseF("r"))
    {
        s ln;
        while (getline(DiseaseFile, ln))
        {
            if (ln != "")
            {
                vs words = extractWrds(ln);
                if (words[1] == name)
                {
                    Disease disease(stoi(words[0]), words[1]);
                    return disease;
                }
            }
        }
        DiseaseFile.close();
    }
    Disease disease;
    return disease;
}

Location getLocationByName(string name)
{
    if (openLocationF("r"))
    {
        s ln;
        while (getline(LocationFile, ln))
        {
            if (ln != "")
            {
                vs words = extractWrds(ln);
                if (words[1] == name)
                {
                    Location location(stoi(words[0]), words[1]);
                    return location;
                }
            }
        }
        LocationFile.close();
    }
    Location location;
    return location;
}


Location getLocationById(int locationId)
{
    if (openLocationF("r"))
    {
        s ln;
        while (getline(LocationFile, ln))
        {
            if (ln != "")
            {
                vs words = extractWrds(ln);
                if (words[0] == to_string(locationId))
                {
                    Location location(stoi(words[0]), words[1]);
                    return location;
                }
            }
        }
        LocationFile.close();
    }
    Location location;
    return location;
}


int getTotalCasesByDisease(int diseaseId)
{
    int total = 0;
    if (openCaseF("r"))
    {
        s ln;
        while (getline(CaseFile, ln))
        {
            if (ln != "")
            {

                vs words = extractWrds(ln);

                if (words[2] == to_string(diseaseId))
                {
                    total += stoi(words[3]);
                }
            }
        }
        CaseFile.close();
    }

    return total;
}

int getTotalCasesByDiseaseAndLocation(int locationId, int diseaseId)
{
    if (openCaseF("r"))
    {
        s ln;
        while (getline(CaseFile, ln))
        {
            if (ln != "")
            {

                vs words = extractWrds(ln);

                if (words[1] == to_string(locationId) && words[2] == to_string(diseaseId))
                {
                    CaseFile.close();
                    return stoi(words[3]);
                }
            }
        }
        CaseFile.close();
    }
    return 0;
}

int getNewLocationId()
{
    int id = 1;
    if (openLocationF("r"))
    {
        s ln;
        while (getline(LocationFile, ln))
        {
            if (ln != "")
            {
                vs words = extractWrds(ln);
                id += stoi(words[0]);
            }
        }
        LocationFile.close();
    }

    return id;
}

/*** Get new ids ***/

int getNewCaseId()
{
    int id = 1;
    if (openCaseF("r"))
    {
        s ln;
        while (getline(CaseFile, ln))
        {
            if (ln != "")
            {
                vs words = extractWrds(ln);
                id += stoi(words[0]);
            }
        }
        CaseFile.close();
    }

    return id;
}

int getNewDiseaseId(){
    int id= 1;
      if (openDiseaseF("r"))
    {
        s ln;
        while (getline(DiseaseFile, ln))
        {
            if (ln != "")
            {
                vs words = extractWrds(ln);
                id += stoi(words[0]);
            }
        }
        DiseaseFile.close();
    }

    return id;
}
Disease getDiseaseById(int id)
{
    Disease disease;

    if (openDiseaseF("r"))
    {
        s ln;
        while (getline(DiseaseFile, ln))
        {
            if (ln != "")
            {
                vs words = extractWrds(ln);
                if (words[0] == to_string(id))
                {
                    disease.setId(stoi(words[0]));
                    disease.setDiseaseName(words[1]);
                    break;
                }
            }
        }
        DiseaseFile.close();
    }

    return disease;
}

map<int, int> getCasesByLocationId(int locationId)
{
    map<int, int> cases;

    if (openCaseF("r"))
    {
        s ln;
        while (getline(CaseFile, ln))
        {
            if (ln != "")
            {
                vs words = extractWrds(ln);

                if (words[1] == to_string(locationId))
                {
                    cases[stoi(words[2])] = stoi(words[3]);
                }
            }
        }
        CaseFile.close();
    }

    return cases;
}

/*** UPDATING DATA ***/

bool findLocation(int id)
{
    if (openLocationF("r"))
    {
        s ln;
        while (getline(LocationFile, ln))
        {
            if (ln != "")
            {
                vs words = extractWrds(ln);
                if (words[0] == to_string(id))
                {
                    LocationFile.close();
                    return true;
                }
            }

            LocationFile.close();
        }
    }
    return false;
}

bool updateCase(Case caseD, int id)
{
    F tempF;
    tempF.open("temp.txt", ios::app);
    if (tempF.is_open() && openCaseF("r"))
    {
        s ln;
        while (getline(CaseFile, ln))
        {
            if (ln != "")
            {
                vs words = extractWrds(ln);
                if (words[0] == to_string(id))
                {
                    tempF << caseD.toString() << "\n";
                }
                else
                {
                    tempF << ln << "\n";
                }
            }
        }
        tempF.close();
        CaseFile.close();
        remove("cases.txt");
        rename("temp.txt", "cases.txt");

            return true;
    }

    return false;
}

/*** DELETING DATA ***/


bool deleteDisease(int id)
{
    F tempF;
    tempF.open("temp.txt", ios::app);
    if (tempF.is_open() && openDiseaseF("r"))
    {
        s ln;
        while (getline(DiseaseFile, ln))
        {
            if (ln != "")
            {
                vs words = extractWrds(ln);
                if (words[0] != to_string(id))
                {
                    tempF << ln << "\n";
                }
            }
        }
        tempF.close();
        DiseaseFile.close();
        remove("diseases.txt");
        rename("temp.txt", "diseases.txt");
       return true;
    }

    return false;
}


bool diseaseExistsInCases(int diseaseId)
{

    if (openCaseF("r"))
    {
        s ln;
        while (getline(CaseFile, ln))
        {
            if (ln != "")
            {
                vs words = extractWrds(ln);
                if (words[2] == to_string(diseaseId))
                {
                    return true;
                }
            }
        }
        CaseFile.close();
    }

    return false;
}

bool handleDeleteLocationDependency(int locationId)
{
    F tempF;
    tempF.open("temp.txt", ios::app);
    if (tempF.is_open() && openCaseF("r"))
    {
        s ln;
        vi diseaseIds;

        while (getline(CaseFile, ln))
        {
            if (ln != "")
            {
                vs words = extractWrds(ln);
                if (words[1] == to_string(locationId))
                {
                   int  diseaseId = stoi(words[2]);
                   diseaseIds.push_back(diseaseId);
                }
                else
                {
                    tempF << ln << "\n";
                }
            }
        }
        tempF.close();
        CaseFile.close();
        remove("cases.txt");
        rename("temp.txt", "cases.txt");

        for (int diseaseId : diseaseIds) 
        {
            if (!diseaseExistsInCases(diseaseId))
                deleteDisease(diseaseId);
        }
        return true;
    }

    return false;
}

bool deleteLocation(int id)
{
    F tempF;
    tempF.open("temp.txt", ios::app);
    if (tempF.is_open() && openLocationF("r"))
    {
        s ln;
        int deletedDep = 0;
        while (getline(LocationFile, ln))
        {
            if (ln != "")
            {
                vs words = extractWrds(ln);
                if (words[0] == to_string(id))
                {
                    deletedDep = 1;
                }
                else
                {
                    tempF << ln << "\n";
                }
            }
       
        }
        tempF.close();
        LocationFile.close();
        remove("locations.txt");
        rename("temp.txt", "locations.txt");

        if(deletedDep == 1){
           handleDeleteLocationDependency(id);
           return true;
        }

}
 return false;
}




/***   HANDLERS      ***/

bool handleAddCase(Case nCase)
{
    int existsId = caseExists(nCase.getLocation().getId(), nCase.getDisease().getId());
    if (existsId == 0)
    {
        return insertCase(nCase);
    }
    else
    {
        nCase.setId(existsId);
        return updateCase(nCase,existsId);
    }
}

/*** OPTIONS ***/

bool isCmdValide(vs cmd_parts)
{
    if ((cmd_parts[0] == "add" || cmd_parts[0] == "delete" || cmd_parts[0] == "list" || cmd_parts[0] == "where") && (cmd_parts.size() == 2))
    {
        return true;
    }
    else if ((cmd_parts[0] == "record") && cmd_parts.size() == 4)
        return true;
    else if (cmd_parts[0] == "cases" && (cmd_parts.size() == 3 || cmd_parts.size() == 2))
        return true;
    else if ((cmd_parts[0] == "help" || cmd_parts[0] == "exit") && cmd_parts.size() == 1)
        return true;

    return false;
}

void handleListLocations()
{
    cout<<"\n\n";
    for (string loc : findAllLocations())
    {
        cout << convertToUpper(loc) << endl;
    }
}

bool handleRecordCase(vs parts)
{
    Location location = getLocationByName(parts[1]);
    Disease disease = getDiseaseByName(parts[2]);
     
     if(location.getId() == 0){
      cout << " Sorry that location doesn't exist\n\n";
      return false;
     }else{
    
    if(disease.getId() == 0){
        disease.setId(getNewDiseaseId());
        disease.setDiseaseName(parts[2]);
        insertDisease(disease);
    }
    Case nCase(getNewCaseId(), location, disease, stoi(parts[3]));

    return handleAddCase(nCase);
    
     }
  
}
void handleListDiseases()
{
    for (string loc : findAllDiseases())
    {
        cout << loc << endl;
    }
}

void handleWhereCmd(vs parts)
{
    Disease disease = getDiseaseByName(parts[1]);
    vi locations = findLocationsByDisease(disease.getId());

    if(locations.size() > 0){
    for (int locationId : locations){
        Location location = getLocationById(locationId);
        cout << "[" << location.getLocationName() << "]\n";
    }
    }else{
        cout << "\nNo location with this disease \n";
    }

}

void handleCasesCmd(vs parts)
{
    if (parts.size() == 2)
    {
        Disease disease = getDiseaseByName(parts[1]);
        cout << " Total cases of '" << parts[1] << "' = " << getTotalCasesByDisease(disease.getId()) << "\n";
    }
    else
    {
        Disease disease = getDiseaseByName(parts[2]);
        Location location = getLocationByName(parts[1]);
        cout << " Cases of " << parts[2] << " at " << parts[1] << " are: " << getTotalCasesByDiseaseAndLocation(location.getId(), disease.getId()) << "\n";
    }
}

void printErrorMess(string type)
{
    if (type == "404")
        cout << "Invalid command ,try again\n";
    else if (type == "505")
        cout << "Error occured ,try again\n";
}


void getMenu()
{
    cout << " ============================================= \n\n";
    cout << "*\t\t\t HELP MENU\t\t\t\n*";
    cout << " ============================================= \n\n";

        cout
         << "add <Location>\t\t\t\t: Add a new location\n"
         << "delete <Location>\t\t\t\t: Delete an existing location\n"
         << "record <Location> <disease> <cases>\t\t\t\t: Record a disease and its cases \n"
         << "list locations\t\t\t\t: List all existing locations\n"
         << "list diseases\t\t\t\t: List existing Diseases in locations\n"
         << "where <disease>\t\t\t\t: Find where disease exists\n"
         << "cases <location><disease>\t\t\t\t: Find cases of a disease in location\n"
         << "cases <disease>\t\t\t\t: Find total cases of a given disease\n"
         << "help \t\t\t\t: Prints user manual\n"
         << "Exit \t\t\t\t: Exit the program\n";
        
        string str;
        cout << "Console >  \n";
        getline(cin, str);
        string cmd;
        getline(cin,cmd);
   
    vs cmd_parts = extractWrds(cmd);
    for(int i=0;i<cmd_parts.size();i++)
         cmd_parts[i] = convertToLower(cmd_parts[i]);
        
    map<string , int> cmds = {{"add" , 0},{"list",1},{"delete" , 2},{"record",3},{"where",4},{"cases",5},{"help",6},{"exit",7}};
    
    if (isCmdValide(cmd_parts))
    {
        Location loc;
        switch(cmds[convertToLower(cmd_parts[0])])
        {
        case 0:
            loc.setId(getNewLocationId());
            loc.setLocationName(cmd_parts[1]);
            if (insertLocation(loc))
            {
                cout << "\n Location " + cmd_parts[1] + " is successfully added! \n";
            }
            break;
         case 1:
            if (cmd_parts[1] == "locations")
                handleListLocations();
            else if (cmd_parts[1] == "diseases")
                handleListDiseases();
            else
                printErrorMess("cmd");
            break;

        case 2:
            loc = getLocationByName(cmd_parts[1]);
            if (deleteLocation(loc.getId()))
                cout << "\n Successfully deleted location \n";
            else
                printErrorMess("505");
            break;
        case 3:
            if (handleRecordCase(cmd_parts))
               cout << "\n Succesffully recorded the new case  \n";
            break;
        case 4:
            handleWhereCmd(cmd_parts);
            break;
        case 5:
            handleCasesCmd(cmd_parts);
            break;

        case 6:
            cout<<"continue\n";
            break;
            
        case 7:
            exit(0);
            break;
        default:
            printErrorMess("cmd");
        }
    }
    else
    {
        cout << "Invalid command ,try again\n";
    }
}
void getOptions()
{

    while (1)
    {
        cout << " ============================================= \n\n";
        cout << "*\t\t\tWelcome to Disease Cases Reporting System!\t\t\t\n*";
        cout << "*\t\t\t********************************************** \n";
        cout << "*\t\t\t\t\t\t\t*\t\t\t\t\t\t \n";
        cout << "*It is developed by 'Dushimimana Samuel' as practical*\n";
        cout << "*evaluation for the end of year 3.*\n";
        cout << " ============================================= \n";
        cout << "Starting Time: Thur Apr 05 23:59:08 CAT 2022.\n";
        cout << "Need a help ? Type 'help' then press Enter key.\n";
        cout << "Console > ";
        string help_cmd;
        cin >> help_cmd;

        if (help_cmd == "help")
        {
            getMenu();
        }
        else
        {
            cout << "Invalid command\n";
        }
    }
}

int main()
{

    getOptions();

    return 0;
}